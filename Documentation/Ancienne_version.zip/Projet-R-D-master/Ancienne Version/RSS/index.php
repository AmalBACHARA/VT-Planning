<html>
<head>

</head>
<body onload="document.location.href='http://www.cva.u-paris10.fr/edt'">
	Redirection vers la page d'accueil ....
</body>
</html>